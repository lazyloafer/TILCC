import kmeans
import time
from CRH import run_CRH
from generate_feature import generate_CRH_feature


dataset = "s4_Relevance"
print("ITLCC:")
for _ in range(20):
    time_start = time.time()
    run_CRH(dataset)
    generate_CRH_feature(dataset)
    kmeans.kmeans(dataset, "feature")
    time_end = time.time()
    time_run = time_end - time_start
    # print('timecost:', time_run, 's')
