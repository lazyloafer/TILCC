import MV_feature
import CRH
import readFile
import kmeans_xjz
import time

# dataset = "s4_Relevance"
# dataset = "d_Duck_Identification"
# dataset = "s5_AdultContent"
# dataset = "WeatherSentiment"
# dataset = "SP"
# dataset = "s4_Dog_data"
# dataset = "d_jn-product"
dataset = "s4_Face_Sentiment_Identification"
# dataset = "trec2010"
# dataset = "HITspam-UsingCrowdflower"
# dataset = "leaves16"
# dataset = "valence7"
# dataset = "valence5"
# dataset = "aircrowd6"
# dataset = "saj2013"
# dataset = "fej2013"
# dataset = "SP"


print("GTIC:")
time_start = time.time()
MV_feature.generate_MV_feature(dataset)
kmeans_xjz.kmeans(dataset, "MV_feature")
time_end = time.time()
time_run = time_end - time_start
print('timecost:', time_run, 's')

# print("ITLCC:")
# time_start = time.time()
# CRH.run_CRH(dataset)
# readFile.generate_CRH_feature(dataset)
# kmeans_xjz.kmeans(dataset, "feature")
# time_end = time.time()
# time_run = time_end - time_start
# print('timecost:', time_run, 's')
