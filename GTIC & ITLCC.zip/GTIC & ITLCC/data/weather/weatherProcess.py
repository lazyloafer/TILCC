import csv

with open("weather_data_set.txt", "r") as f:
    lines = f.readlines()

answer_dict = dict()
answer_index = 0

question_dict = dict()
question_index = 0

worker_dict = dict()
worker_index = 0

csvfile = open("answer.csv", "w", newline='')
writer = csv.writer(csvfile)
writer.writerow(["question", "worker", "answer"])

for line in lines:
    answer = line.split("\t")[1]
    if 'w' in answer:
        if answer not in answer_dict:
            answer_dict[answer] = answer_index
            answer_index = answer_index + 1
        question = line.split("\t")[0]
        if question not in question_dict:
            question_dict[question] = question_index
            question_index = question_index + 1
        worker = line.split("\t")[2].strip()
        if worker not in worker_dict:
            worker_dict[worker] = worker_index
            worker_index = worker_index + 1
        writer.writerow([question_dict[question], worker_dict[worker], answer_dict[answer]])
csvfile.close()

with open("weather_ground_truth.txt", "r") as f:
    goldlines = f.readlines()

truth_csv = open("truth.csv", "w", newline='')
truth_writer = csv.writer(truth_csv)
truth_writer.writerow(["question", "answer"])
count = 0
for goldline in goldlines:
    answer = goldline.split("\t")[1].strip()
    if 'w' in answer:
        question = goldline.split("\t")[0]
        if question not in question_dict:
            print(question)
            count = count + 1
        else:
            truth_writer.writerow([question_dict[question], answer_dict[answer]])
truth_csv.close()
print(count)
